"""
Implementation of different beam reduction methods
""" 
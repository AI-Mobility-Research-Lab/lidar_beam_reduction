"""
Utility functions for LiDAR beam reduction
""" 
 
"""
Test suite for LiDAR beam reduction
""" 